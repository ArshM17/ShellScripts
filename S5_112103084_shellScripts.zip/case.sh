#!/bin/bash
echo 'Pick a number between 1 - 7'
read num
case $num in 
	1) echo "Today is Monday"
	;;
	2) echo "Today is Tuesday"
	;;
	3) echo "Today is Wednesday"
	;;
	4) echo "Today is Thursday"
	;;
	5) echo "Today is Friday"
	;;
	6) echo "Today is Saturday"
	;;
	7) echo "Today is Sunday"
	;;
esac


