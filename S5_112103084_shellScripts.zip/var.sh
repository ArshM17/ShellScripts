#!/bin/bash
arr=(1 4 9 16 25)
echo ${arr[*]}
echo ${arr[2]}
echo ${#arr[*]}
