echo Hello World
echo Hey How are you?
echo I hope you are doing fine.
