#!/bin/bash
num1=10
num2=20
if [ $num1 -eq $num2 ]
then
	echo Values in num1 and num2 are equal.
else
	echo Values in num1 and num2 are not equal.
fi
