#!/bin/bash
echo 'Even numbers from 1 to 20 are as follows:'
for number in {2..20..2}
do
	echo $number
done
